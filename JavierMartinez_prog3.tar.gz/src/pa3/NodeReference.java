package pa3;

import java.io.Serializable;

public class NodeReference implements Serializable
{
	/**
	 * 
	 */
	private static final long serialVersionUID = -2177267932810219538L;
	int id;
	
	public NodeReference(int id)
	{
		this.id = id;
	}
	
	
}
