package pa3;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Scanner;

public class Runner {
	/*
	static ArrayList<Tuple> hilbertValues;
	private static int currentID;
	public static void main(String[] args) throws FileNotFoundException
	{
		hilbertValues = new ArrayList<Tuple>(30000);
		Scanner sc = new Scanner(new File("project3dataset30K-1.txt"));
		sc.useDelimiter(",\\s*|\\s+");
		while(sc.hasNext())
		{
			int x = sc.nextInt();
			int y = sc.nextInt();
			hilbertValues.add(new Tuple(x, y, RTree.getHilbertValue(x, y)));
		}
		currentID = -1;
		Collections.sort(hilbertValues);
		System.out.println("Done sorting!");
		System.out.println(hilbertValues.size());
		sc.close();
	}
	*/
}
